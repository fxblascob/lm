<?php
    $html ="<p>Lista obtenida desde el fichero 'listado.txt'";
    $html .= "<ul>";
    $fichero = file('listado.txt');
    foreach ($fichero as $fila){
        $html .= "<li> ".$fila."</li>";
    }
    $html .= "</ul>";
    echo $html;
?>