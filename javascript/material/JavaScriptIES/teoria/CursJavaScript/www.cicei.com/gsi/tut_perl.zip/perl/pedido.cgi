#!/usr/bin/perl

# Generamos el contenido del fichero pedido_ticket.dat
# Este fichero contendr� lo siguiente (en caracteres):
# Parte de ventas: c�digo de art�culo(10) - Descripci�n(40) - Unidades(2) - Precio de venta(8)
# Datos usuario: nombre y apellidos(40) - C�digo Postal(40) - Correo electr�nico(30)
# Recibimos los datos de importe.pl

# La siguiente funci�n tomar� los datos y los colocar� en el fichero pedido_ticket.dat

sub Compra {
	# Acceso a STDIN mediante la funci�n read
	read(STDIN, $inputString, $ENV{CONTENT_LENGTH});
	if ($inputString eq "") {
		return;
	}
	 #Separa la cadena de caracteres de una lista
	#$inputString = "ticket=01159&codigo=0000000001&descrip=Ordenador+386+4Mb/250Mb+Monitor+B/N+VGA+&quanty=02&precio=000095120&codigo=0009657433&descrip=Caja+de+100+diskettes+3.5+- HD++++++++++&quanty=01&precio=000009123&codigo=0000032332&descrip=Autodesk+AutoCAD+12+para+Windows++++++++&quanty=02&precio=000076453&nombre=Alejandro+Garcia&CP=35012&Email=root";
	@nameValue = split(/&/, $inputString);
	# recorre la lista
	$i = 0;
	$outristra = "";
	foreach( @nameValue) {
		# separa el par nombre-valor
		($name,$value) = split(/=/, $_);
		# decodifica valores
		$value =~ s/\%(..)/pack("c", hex($1))/ge;
		$value =~ tr/+/ /;
		if ((($name eq "nombre") || ($name eq "CP")) || ($name eq "Email")) {
			$outristra .= $value. "\n";
			if ($name eq "Email") {
				$outristra = "\n" . $outristra;
				print PEDIDO $outristra;
			}
		}
		elsif ($name eq "ticket") {
			$ristra = ">pedido_" . $value . ".dat";
			open(PEDIDO, $ristra);
		}
		else {
			$i++;
			$outristra .= $value;
			if ($i == 4) {
				$i = 0;
				$outristra .= "\n";
				print PEDIDO $outristra;
				$outristra = "";				
			}
		}
	}
	close(PEDIDO);
	return $value;       # El �ltimo value es el correo electr�nico
}


# Creamos la p�gina en la que se verifica el �xito del pedido
# Le enviamos un Email de comfirmaCI�N del pedido

sub  CreaPagina {
	# Mandamos un Email al cliente
	$mail = &Compra();
	printf ("Content-Type: text/html\n\n");
	open(MAILOUT, "|mail -s \"Confirmaci�n de compra: Ale Computer\"$mail");
	print MAILOUT "EL pedido le llegar� en menos de 15 d�as.\nGracias por su visita.";
	close(MAILOUT);
	# Creamos p�gina de despedida
	print <<_LABEL_;
	<HEAD><TITLE>Ale Computer: Pedidos</TITLE></HEAD>
	<BODY>
	<CENTER>
	<P>
	<P>
	<H2>El pedido ha sido confirmado. Se le enviar&aacute; un correo electr&oacute;nico
	de confirmaci&oacute;n. Si no le llega este correo p&oacute;ngase en contacto con
	nosotros para confirmar dicho pedido.
	<P>
	<I>Gracias por su visita</I>
	</H2>
	<P>
	<P>
	<A HREF= \"entrada.htm\">Seguir Comprando</A>
	</CENTER>
	</BODY>
_LABEL_

}

# Programa principal:

# Escribimos el fichero pedido.
# Mandamos un e-mail de confirmaci�n al cliente.
# Creamos p�gina de despedida.

&CreaPagina();