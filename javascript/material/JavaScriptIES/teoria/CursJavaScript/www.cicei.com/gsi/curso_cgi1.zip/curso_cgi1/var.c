main()
{
	/*printf("Content-type: text/html\n\n");*/
	printf("<html>\n");
	printf("<body background=%cfondoam.gif%c>\n",34,34);
	printf("<img src=%cpookline.gif%c><h1><center>Variables de Entorno</center></h1>",34,34);
	printf("<img src=%cpookline.gif%c><p>",34,34);
	printf("<b>SERVER_SOTWARE</b>= %s",getenv("SERVER_SOTWARE"));
	printf("<BR>");	
	printf("<B>SERVER_NAME</b>= %s<BR>",getenv("SERVER_NAME"));
	printf("<b>GATEWAY_INTERFACE</b>= %s<BR>",getenv("GATEWAY_INTERFACE"));
	printf("<b>SERVER_PROTOCOL</b>= %s<BR>",getenv("SERVER_PROTOCOL"));
	printf("<b>SERVER_PORT</b>= %s<BR>",getenv("SERVER_PORT"));
	printf("<b>REQUEST_METHOD</b>= %s<BR>", getenv("REQUEST_METHOD"));
	printf("<b>SCRIPT_NAME</b>= %s<BR>",getenv("SRIPT_NAME"));
	printf("<b>REMOTE_HOST</b>= %s<BR>",getenv("REMOTE_HOST"));
	printf("<b>REMOTE_ADDR</b>= %s<BR>",getenv("REMOTE_ADDR"));
	printf("<b>AUTH_TYPE</b>= %s<BR>", getenv("AUTH_TYPE"));
	printf("<b>REMOTE_USER</b>= %s<BR>",getenv("REMOTE_USER"));
	printf("<b>REMOTE_IDENT</b>= %s<BR>", getenv("REMOTE_IDENT"));
	printf("<b>CONTENT_TYPE</b>= %s<BR>", getenv("CONTENT_TYPE"));
	printf("<b>CONTENT_LENGTH</b>= %s<BR>", getenv("CONTENT_LENGTH"));
	printf("<b>PATH_INFO</b>= %s<BR>", getenv("PATH_INFO"));
	printf("<b>QUERY_STRING</b>= %s<BR>", getenv("QUERY_STRING"));
	printf("<b>PATH_TRANSLATED</b>= %s<BR>", getenv("PATH_TRANSLATED"));
	printf("<b>HTTP_ACCEPT</b>= %s<BR>", getenv("HTTP_ACCEPT"));
	printf("<b>HTTP_USER_AGENT</b>= %s<BR>", getenv("HTTP_USER_AGENT")); 
	printf("<br><hr>");
	printf("<a href=%cvar.htm%c><blockquote><img src=%clistadot.gif %c border=0>  Volver al Fuente</blockquote></a>",34,34,34,34);
	printf("<hr>");
	printf("</html>\n");
	printf("</body>\n");
	
	
}
