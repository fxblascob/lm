#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
	char *nombre;
	int valor;
}entry;


main()
{
	int pos,i,op1,op2,op,res,tam_qs,tam_ptr;
	char *s, *qs, *ptr, *name, *dest;
	entry entrada[3];

	
/*	printf("Content-type:text/html\n");
        printf("\n");
*/	printf("<html>\n");
	printf("<body background=%cfondoam.gif%c>\n",34,34);
	
        printf("<img src=%cpookline.gif%c>",34,34);
	printf("<h1><center><font color=%c#800000%c> SOLUCION</font></center></h1>",34,34);
	printf("<img src=%cpookline.gif%c><br>",34,34);
	 

	if (!strcmp(getenv("REQUEST_METHOD"),"GET"))
	{ 

		s=getenv("QUERY_STRING");
		qs=(char *)malloc(strlen(s)+1);
                (void)strcpy(qs,s); 


		for (i=0;i<3;i++)
		{
			entrada[i].nombre=(char *)malloc(1024);

			ptr=strchr(qs,'&');
                        if (ptr==NULL){ ptr=qs; tam_ptr=0;}
                        else tam_ptr=strlen(ptr);
			tam_qs=strlen(qs);
                        

	           	pos=tam_qs-tam_ptr;
                        dest=(char *)malloc(pos);
			strncpy(dest,qs,pos);
			dest[pos]='\0';
        
		        qs=ptr+1;
                      	
        
			ptr=strchr(dest,'=');
			tam_qs=strlen(dest);
                        tam_ptr=strlen(ptr);
			pos=tam_qs-tam_ptr;
        
                        name=(char *)malloc(pos);               
			strncpy(name,dest,pos);
      

  			name[pos]='\0';


			entrada[i].nombre=name;
			dest=ptr+1;
			entrada[i].valor=atoi(dest);
 

                        free(dest);
		        free(name);
		}

          printf("<H2>");

          op1=entrada[0].valor;
          op=entrada[1].valor;
          op2=entrada[2].valor;

          printf("<H2>"); 
	  switch (op)
	  {
		case 1:res=op1+op2;
			   break;
		case 2:res=op1-op2;
			   break;
		case 3:res=op1*op2;
			   break;
		case 4:res=op1/op2;
			   break;
		
          }
	  printf("<h2>El resultado es: %d</h2>",res);

	}
	else{
          printf("ERROR");
	}

        printf("<p><HR><br><center> <A HREF=\"calcu.htm\"><IMG SRC=\"hand.gif\" border=0><h4>Volver a la calculadora</h4></A></center>");
        printf("<BR>");
	printf("</body>\n");
	printf("</html>\n");


}
