#include <stdlib.h>
#include <string.h>
#include <stdio.h>

main()
{
        
        int i;
	

        printf("<html>\n");
        printf("<head><title>prueba</title></head>\n");
        printf("<body background=%cfondoam.gif%c",34,34);
	
	printf("<br><img src=%cpookline.gif%c>",34,34);
	fflush(stdout);

        printf("<H1><center><font color=#800000> Ejemplo de Programaci&oacute;n CGI</font></center></H1>");
	printf("<h2><center><font color=#800000> El tiempo es Oro</font></center></h2>");
	printf("<img src=%cpookline.gif%c>",34,34);
	printf("<p><h2><img src=%ccalendt.gif%c align=middle>   Hoy es d&iacute;a  ",34,34);
        fflush(stdout);
	
        i=system("date +\"%e-%m-%Y\"");

        printf("<p>");
	printf("<img src=%chttp://algol.ulpgc.es/~lastrex/practica/nph-anima.cgi?listado4.lst%c>    La hora es:  ",34,34);
	
	fflush(stdout);


	i=system("date +\"%H:%M:%S\"");

	printf("</h2><br><hr><br>");

	printf("<br><center><a href=%creloj.htm%c><img src=%clistadot.gif%c border=0> Volver al listado</a></center><br><br>",34,34,34,34);

	printf("<hr>\n</body>\n");
        printf("</html>");
}

