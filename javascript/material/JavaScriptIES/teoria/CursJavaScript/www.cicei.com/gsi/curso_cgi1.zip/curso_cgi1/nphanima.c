#include <stdio.h>
#include <stdlib.h>
#include <string.h>   

#define listanim "/home/lastrex/html/lista/"
#define imaganim "/home/lastrex/html/anim/" 

main(int argc,char *argv[])
{
  FILE *fp=NULL;
  FILE *fp2=NULL;

  char* status;
  char line[80];
  char file[132];
  char image_list[132];
  int lg_line=80;
  int buf,n,cont,i=0;
  cont=1;
  printf("HTTP/1.0 200 Okay\n"); 

  printf("Content-Type:multipart/x-mixed-replace;boundary=sometext\n");
  printf("\n--sometext\n");
  while(i<100){
  strcpy(image_list,listanim); 
  strcat(image_list,argv[1]);

  fp=fopen(image_list,"r"); 

  status=fgets(line,lg_line,fp);
  line[strlen(line)-1]='\0';
  while(status!=NULL)
  { 
    strcpy(file,imaganim);
    strcat(file,line); 

    printf("Content-Type: image/gif\n");
    printf("\n");
    fp2=fopen(file,"r");
    buf=fgetc(fp2);
    while (buf!=EOF)
    {
      printf("%c",buf);
      buf=fgetc(fp2);
    }
    fclose(fp2);
    printf("\n--sometext\n");
   status=fgets(line,lg_line,fp);
    line[strlen(line)-1]='\0';
  } 
  fclose(fp);
  i++;
  }
}
