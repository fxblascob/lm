#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main()
{
	FILE *fp=NULL;
	FILE *out=NULL;
        char numb[80];
        int num;

   fp=fopen("count.txt","r");
   fgets(numb,80,fp);
   fclose(fp);
   num=atoi(numb);
   num++;

   out=fopen("count.txt","w");
   fprintf(out,"%d",num);
   fclose(out); 

	
printf("<HTML>");
printf("<HEAD>");
printf(" <TITLE> PORTADA </TITLE>");
printf("</HEAD>");
printf("<BODY BACKGROUND=\"fondoam.gif\">");
printf("<P>");
printf("<CENTER>");
printf("<IMG SRC=\"titulo.gif\" BORDER=0 HEIGHT=175 WIDTH=523 ALIGN=CENTER>");

printf("</CENTER>");

printf("<A HREF=\"frame1.htm\"><IMG SRC=\"bebe1.gif\" ALT=\"Introduccion HTML\" HSPACE=50 VSPACE=20 HEIGTH=350 WIDTH=211 BORDER=0 ></a>");
printf("<A HREF=\"frame2.htm\"><IMG SRC=\"bebe2.gif\" HSPACE=20 VSPACE=20 HEIGHT=349 WIDTH=205 BORDER=0></A>");
 
printf("<HR><BR>");

printf("<UL>");
printf("<H2><img src=\"bola2t.gif\"><A HREF=\"frame1.htm\">INTRODUCCION AL HTML</A></H2>");

printf("<H2><img src=\"bola2t.gif\"><A HREF=\"frame2.htm\">PROGRAMACION CGI </A></H2>");
printf("</UL>");

printf("<P><BR>");

printf("<HR></P>"); 
printf("<br><ul><H2><img src=\"bola2t.gif\"><a href=\"direcc.htm\">ALGUNAS DIRECCIONES DE INTERES</A></H2></ul><br><HR><BR>");
printf("<H3><font color=\"#800000\">SI QUIERES CONOCERNOS:</font></h3>");
printf("<BLOCKQUOTE>");
printf("<P><I><FONT COLOR=\"#800000\">");
printf("<A HREF=\"pilar.htm\" TARGET=\"_top\">");
printf("<IMG  SRC=\"sellot.gif\" ALIGN=left WIDTH=34 HEIGHT=36 border=0 hspace=20>Pilar</A>");
printf("Tarri&ntilde;o Su&aacute;rez <BR>");
printf("a1551@correo.dis.ulpgc.es</FONT></I></P>");

printf("<P><FONT COLOR=\"#800000\"> <I><A HREF=\"iratxe.htm\" TARGET=\"_top\">");
printf("<IMG  SRC=\"sellot.gif\" ALIGN=left WIDTH=34 HEIGHT=36 border=0 hspace=20>Iratxe</a>");
printf("Peraita Aguilar <BR>");
printf("a1082@correo.dis.ulpgc.es</I></FONT></P>");

printf("<P><FONT COLOR=\"#800000\"> <I><A HREF=\"bela.htm\" TARGET=\"_top\">");
printf("<IMG  SRC=\"sellot.gif\" ALIGN=left WIDTH=34 HEIGHT=36 border=0 hspace=20>Bela</A>");
printf("Chugani Pirshotam<BR>");
printf("a1166@correo.dis.ulpgc.es</I></FONT></P>");
printf("</BLOCKQUOTE>");

printf("<HR><center><BR><H1>Bienvenido a nuestra p&aacutegina: </H1>");
printf("<H2>Eres el visitante n&uacutemero : ");
printf("<font color=#ff0000>%d</font></H2>",num);  
printf("</center><HR><br>");
printf("</BODY>"); 
printf("</HTML>");


 }
