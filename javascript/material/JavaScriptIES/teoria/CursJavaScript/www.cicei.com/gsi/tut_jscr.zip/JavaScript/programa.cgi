#!/usr/bin/perl

# Tomamos los datos de un formulario mediante el m�todo POST.
# Mostramos los pares variable valor

read(STDIN, $inputString, $ENV{CONTENT_LENGTH});
if ($inputString eq "") {
	exit;
}
print ("Content-Type: text/html\n\n");
print "<BODY bgcolor=\"White\">\n";
# Separa la cadena de caracteres de una lista
@nameValue = split(/&/, $inputString);
# recorre la lista
foreach(@nameValue) {
	# separa el par nombre-valor
	($name,$value) = split(/=/, $_);
	print "$name = $value <BR>\n";
}
print "<P><CENTER>\n";
print "<a href=\"cap7.html\">Volver</a>\n";
print "</CENTER>\n";
print "</BODY>\n";

